# PowerShell script to update deck abilities with standardized text

$deckPath = "data/deck.json"
$backupPath = "data/deck_backup.json"

# Create backup
Copy-Item $deckPath $backupPath
Write-Host "Backup created: $backupPath"

# Read the deck file
$deckContent = Get-Content $deckPath -Raw

# Define ability mappings
$abilityMappings = @{
    '"Double power vs red"' = '"Double this card''s power when battling red cards"'
    '"Double power vs blue"' = '"Double this card''s power when battling blue cards"'
    '"+1 when attacking"' = '"Increase this card''s power by 1 when attacking"'
    '"+1 when defending"' = '"Increase this card''s power by 1 when defending"'
    '"+1 power this turn"' = '"Increase target card''s power by 1 this turn"'
    '"+1 value when played"' = '"Increase this card''s value by 1 when played"'
    '"Draw 1 card"' = '"Draw 1 card from deck"'
    '"Discard 1 card"' = '"Target opponent discards 1 card from hand"'
    '"Steal 1 card"' = '"Steal 1 random card from opponent''s hand"'
    '"Revive from graveyard"' = '"Move 1 target card from your graveyard to your hand"'
    '"Destroy 1 unit"' = '"Destroy 1 target opponent''s unit"'
    '"Immune to black"' = '"Immune to abilities from black cards"'
    '"Copy enemy ability"' = '"Copy target enemy card''s ability this turn"'
}

# Apply replacements
foreach ($old in $abilityMappings.Keys) {
    $new = $abilityMappings[$old]
    $deckContent = $deckContent.Replace($old, $new)
    Write-Host "Replaced: $old -> $new"
}

# Remove cards with "Gain extra turn" and "Heal 1 unit" (game flow modifiers)
# This is more complex, so we'll identify and remove these cards
$jsonObject = $deckContent | ConvertFrom-Json
$originalCount = $jsonObject.Count

# Filter out cards with game flow modifier abilities
$filteredCards = $jsonObject | Where-Object { 
    $_.ability -ne "Gain extra turn" -and $_.ability -ne "Heal 1 unit" 
}

$newCount = $filteredCards.Count
Write-Host "Removed $($originalCount - $newCount) cards with game flow modifier abilities"

# Convert back to JSON and save
$updatedContent = $filteredCards | ConvertTo-Json -Depth 10
Set-Content $deckPath $updatedContent

Write-Host "Deck updated successfully!"
Write-Host "Cards remaining: $newCount"
