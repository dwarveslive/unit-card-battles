#!/usr/bin/env node

// Script to update deck.json with standardized ability text
// Run this script to apply the new standardized ability definitions

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { standardizeAbilities } from '../src/abilities/abilityDefinitions.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function updateDeck() {
  try {
    const deckPath = path.join(__dirname, '../data/deck.json');
    
    // Read current deck
    console.log('Reading current deck...');
    const rawData = fs.readFileSync(deckPath, 'utf8');
    let deck = JSON.parse(rawData);
    
    console.log(`Original deck has ${deck.length} cards`);
    
    // Create backup
    const backupPath = path.join(__dirname, '../data/deck_backup.json');
    fs.writeFileSync(backupPath, rawData);
    console.log(`Backup created at ${backupPath}`);
    
    // Apply standardized abilities
    console.log('Applying standardized abilities...');
    const updatedDeck = standardizeAbilities(deck);
    
    console.log(`Updated deck has ${updatedDeck.length} cards`);
    
    if (updatedDeck.length < deck.length) {
      console.log(`⚠️  ${deck.length - updatedDeck.length} cards were removed due to invalid abilities`);
    }
    
    // Show some examples of changes
    console.log('\n📝 Example ability changes:');
    for (let i = 0; i < Math.min(5, updatedDeck.length); i++) {
      const original = deck.find(c => c.id === updatedDeck[i].id);
      if (original && original.ability !== updatedDeck[i].ability) {
        console.log(`  ${original.name}:`);
        console.log(`    OLD: "${original.ability}"`);
        console.log(`    NEW: "${updatedDeck[i].ability}"`);
        console.log();
      }
    }
    
    // Write updated deck
    const updatedJson = JSON.stringify(updatedDeck, null, 2);
    fs.writeFileSync(deckPath, updatedJson);
    
    console.log('✅ Deck updated successfully!');
    console.log(`📁 Original deck backed up to: ${backupPath}`);
    
  } catch (error) {
    console.error('❌ Error updating deck:', error);
    process.exit(1);
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  updateDeck();
}
