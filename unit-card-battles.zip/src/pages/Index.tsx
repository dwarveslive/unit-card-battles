import { MultiplayerGameManager } from '@/components/game/MultiplayerGameManager.tsx';

const Index = () => {
  return <MultiplayerGameManager />;
};

export default Index;
